import logo from './logo.svg';
import './App.css';
import List from './qd01/List';

function App() {
  return (
    <List />
  );
}

export default App;
